package com.techelevator.tenmo.model;

import java.math.BigDecimal;
import java.util.List;

public class Transfers{

    private int transferId;
    private int transferTypeId;
    private int transferStatusId;
    private int accountFrom;
    private int accountTo;
    private BigDecimal amount;
    private String transferType;
    private String transferStatus;
    private String userFrom;
    private String userTo;
    private Account transferService;

    private List transferHistory;

    // Getters and Setters
    public String getUserFrom() {
        return userFrom;
    }

    public void setUserFrom(String userFrom) {
        this.userFrom = userFrom;
    }

    public String getUserTo() {
        return userTo;
    }

    public void setUserTo(String userTo) {
        this.userTo = userTo;
    }

    public String getTransferType() {
        return transferType;
    }
    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }
    public String getTransferStatus() {
        return transferStatus;
    }
    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }
    public int getTransferId() {
        return transferId;
    }
    public void setTransferId(int transferId) {
        this.transferId = transferId;
    }
    public int getTransferTypeId() {
        return transferTypeId;
    }
    public void setTransferTypeId(int transferTypeId) {
        this.transferTypeId = transferTypeId;
    }
    public int getTransferStatusId() {
        return transferStatusId;
    }
    public void setTransferStatusId(int transferStatusId) {
        this.transferStatusId = transferStatusId;
    }
    public int getAccountFrom() {
        return accountFrom;
    }
    public void setAccountFrom(int accountFrom) {
        this.accountFrom = accountFrom;
    }
    public int getAccountTo() {
        return accountTo;
    }
    public void setAccountTo(int accountTo) {
        this.accountTo = accountTo;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    // New method to send bucks
    public boolean sendBucks(BigDecimal amount) {
        // Check if the transfer is valid
        if (accountFrom == accountTo) {
            System.out.println("Cannot transfer money to the same account.");
            return false;
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("Amount must be greater than zero.");
            return false;
        }
        if (transferService.getBalance().compareTo(amount) < 0) {
            System.out.println("Insufficient funds.");
            return false;
        }
        // Perform the transfer
        boolean success = transferService.transferFunds();
        if (success) {
            System.out.println("Transfer successful.");
            this.accountFrom = accountFrom;
            this.accountTo = accountTo;
            this.amount = amount;
            this.transferStatus = "Completed";
            return true;
        } else {
            System.out.println("Transfer failed.");
            this.transferStatus = "Failed";
            return false;
        }
    }
}
