package com.techelevator.tenmo.model;

import java.util.Objects;

public class User {

    private int userId;
    private String username;

    public int getuserId() {
        return userId;
    }

    public void setId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof User) {
            User otherUser = (User) other;
            return otherUser.getuserId() == userId
                    && otherUser.getUsername().equals(username);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, username);
    }

    public int setuserId() {
    return userId;
    }
}
