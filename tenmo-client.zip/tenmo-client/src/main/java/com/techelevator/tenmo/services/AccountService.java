package com.techelevator.tenmo.services;

import com.techelevator.tenmo.model.Account;
import com.techelevator.tenmo.model.AuthenticatedUser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;

public class AccountService {

    private static final String BALANCE_ENDPOINT = "/balance/";
    private final String baseUrl;
    private final RestTemplate restTemplate;
    private String authToken = null; //goes in every service

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public AccountService(String url) {
        this.baseUrl = url;
        this.restTemplate = new RestTemplate();

    }

    public BigDecimal getBalance() {
        BigDecimal balance = BigDecimal.ZERO;
        try {
            Account account = restTemplate.exchange(
                    baseUrl +
                            //currentUser.getUser().getId()
                            "/account",
                    HttpMethod.GET,
                    makeAuthEntity(),
                    Account.class
            ).getBody();
            balance = account.getBalance();

        } catch (RestClientException e) {
            System.out.println("Error getting balance: " + e.getMessage());
        }
        return balance;
    }

    private HttpEntity<Void> makeAuthEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(authToken);
        return new HttpEntity<>(headers);
    }

    public Account[] getAccounts() {
    return getAccounts();
    }
}
