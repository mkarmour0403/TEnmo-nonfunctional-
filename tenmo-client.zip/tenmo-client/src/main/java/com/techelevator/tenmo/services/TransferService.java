package com.techelevator.tenmo.services;

import com.techelevator.tenmo.App;
import com.techelevator.tenmo.model.Account;
import com.techelevator.tenmo.model.AuthenticatedUser;
import com.techelevator.tenmo.model.Transfers;
import com.techelevator.tenmo.model.User;
import com.techelevator.util.BasicLogger;
import org.springframework.http.*;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import java.math.BigDecimal;
import java.util.Scanner;
import static com.techelevator.tenmo.App.API_BASE_URL;

public class TransferService {
    private static final String API_BASE_URL = "http://localhost:8080/";
    private final String BASE_URL;
    private final AuthenticatedUser currentUser;
    private static final RestTemplate restTemplate = new RestTemplate();
    private String authToken = null; //goes in every service

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
    public TransferService(String url, AuthenticatedUser currentUser) {
        super();
        this.BASE_URL = url;
        this.currentUser = currentUser;
    }
    public void sendBucks() {
        User[] users = null;
        Transfers transfer = new Transfers();
        try (Scanner scanner = new Scanner(System.in)) {
            users = getUsers();
            if (users != null) {
                displayUsers(users);
                System.out.print("Enter ID of user you are sending to (0 to cancel): ");
                int recipientId = Integer.parseInt(scanner.nextLine());
                if (recipientId != 0) {
                    transfer.setAccountTo(recipientId);
                    transfer.setAccountFrom(currentUser.getUser().getuserId());
                    System.out.print("Enter amount: ");
                    try {
                        BigDecimal amount = new BigDecimal(scanner.nextLine());
                        transfer.setAmount(amount);
                        String output = restTemplate.exchange(BASE_URL + "transfer", HttpMethod.POST, makeTransferEntity(transfer), String.class).getBody();
                        System.out.println(output);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid amount format.");
                    }
                }
            }
        } catch (RestClientResponseException e) {
            System.out.println("Error sending bucks: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
    private void displayUsers(User[] users) {
        System.out.println("-------------------------------------------");
        System.out.println("Users");
        System.out.println("ID\t\tName");
        System.out.println("-------------------------------------------");
        for (User user : users) {
            System.out.println(user.getuserId() + "\t\t" + user.getUsername());
        }
    }
    private User[] getUsers() {
        User[] users = null;
        // Implement the method to retrieve users from the API
        try {
            users = restTemplate.exchange(API_BASE_URL + "users", HttpMethod.GET, makeAuthEntity(), User[].class).getBody();
        } catch (RestClientResponseException e) {
            System.out.println("Error retrieving users: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
        return users;
    }
    public User[] listUsers() {
        User[] users = null;
        try {
            users = restTemplate.getForObject(BASE_URL + "users", User[].class);
        } catch (RestClientResponseException | ResourceAccessException e) {
            BasicLogger.log(e.getMessage());
        }
        return users;
    }
    private HttpEntity<Void> makeAuthEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(currentUser.getToken());
        return new HttpEntity<>(headers);
    }

//    public void transfersList() {
//        Transfers[] transfers = null;
//        try {
//            transfers = restTemplate.exchange(BASE_URL + "transfers/" +
//                    currentUser.getUser().getuserId(), HttpMethod.GET, makeAuthEntity(),
//                    Transfers[].class).getBody();
//            if (transfers != null) {
//                displayTransfers(transfers);
//            }
//        } catch (RestClientResponseException e) {
//            System.out.println("Error retrieving transfers: " + e.getMessage());
//        } catch (Exception e) {
//            System.out.println("Unexpected error: " + e.getMessage());
//        }
//    }

    public static Transfers[] listTransfers() {
        Transfers[] transfers = null;
        try {
            transfers = restTemplate.getForObject(API_BASE_URL + "/account/transfers", Transfers[].class);
        } catch (RestClientResponseException | ResourceAccessException e) {
            BasicLogger.log(e.getMessage());
        }
        return transfers;
    }
    private void displayTransfers(Transfers[] transfers) {
        System.out.println("-------------------------------------------");
        System.out.println("Transfers");
        System.out.println("ID\t\tFrom/To\t\tAmount");
        System.out.println("-------------------------------------------");
        for (Transfers transfer : transfers) {
            String fromOrTo = (transfer.getAccountFrom() == currentUser.getUser().getuserId()) ? "To: " : "From: ";
            System.out.println(transfer.getTransferId() + "\t\t" + fromOrTo + "\t\t" + transfer.getAmount());
        }
    }
    public void approveOrRejectTransfer() {
        Transfers transfer = new Transfers();
        Transfers[] transfers = null;
        try (Scanner scanner = new Scanner(System.in)) {
            try {
                transfers = restTemplate.exchange(BASE_URL + "transfers/" + currentUser.getUser().getuserId(), HttpMethod.GET, makeAuthEntity(), Transfers[].class).getBody();
                if (transfers != null) {
                    displayTransfers(transfers);
                    System.out.print("Enter ID of transfer you would like to approve or reject (0 to cancel): ");
                    int transferId = Integer.parseInt(scanner.nextLine());
                    if (transferId != 0) {
                        System.out.println("Would you like to approve or reject this request?: ");
                        String transferStatus = scanner.nextLine();
                        if (transferStatus.equalsIgnoreCase("approve")) {
                            transfer.setAccountTo(transferId);
                            transfer.setTransferStatus("approved");
                        } else {
                            transfer.setAccountTo(transferId);
                            transfer.setTransferStatus("rejected");
                        }
                    }
                }

            } catch (RestClientResponseException e) {
                System.out.println("Error retrieving transfers: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        } catch (RestClientResponseException e) {
            System.out.println("Error approving/rejecting transfer: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
    public void transfersRequestList() {
        Transfers[] transfers = null;
        try {
            transfers = restTemplate.exchange(BASE_URL+ "transfers/pending/" + currentUser.getUser().setuserId(), HttpMethod.GET, makeAuthEntity(), Transfers[].class).getBody();
            if (transfers != null) {
                displayTransfers(transfers);
            }
        } catch (RestClientResponseException | ResourceAccessException e) {
            System.out.println("Error retrieving pending transfers: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
    private HttpEntity<Transfers> makeTransferEntity(Transfers transfer) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(currentUser.getToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new HttpEntity<>(transfer, headers);
    }

    public void requestBucks() {
    }
}
