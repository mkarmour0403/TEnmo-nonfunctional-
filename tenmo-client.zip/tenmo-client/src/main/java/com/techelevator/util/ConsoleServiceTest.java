package com.techelevator.util;

import com.techelevator.tenmo.services.ConsoleService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;

public class ConsoleServiceTest {

    private final InputStream systemIn = System.in;
    private final PrintStream systemOut = System.out;

    private ByteArrayInputStream testIn;
    private ByteArrayOutputStream testOut;

    private ConsoleService consoleService;

    @Before
    public void setUp() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @After
    public void tearDown() {
        System.setIn(systemIn);
        System.setOut(systemOut);
    }

    @Test
    public void testPrintGreeting() {
        // Given
        consoleService = new ConsoleService();

        // When
        consoleService.printGreeting();

        // Then
        assertEquals("Expected greeting message", "Welcome to TEnmo!", getOutput().trim());
    }

    @Test
    public void testPromptForMenuSelection() {
        // Given
        consoleService = new ConsoleService();
        String simulatedUserInput = "1\n";
        provideInput(simulatedUserInput);

        // When
        int selection = consoleService.promptForMenuSelection("Please choose an option: ");

        // Then
        assertEquals("Expected menu selection", 1, selection);
    }

    // Add similar tests for other methods like printLoginMenu(), promptForCredentials(), etc.

    // Helper methods to simulate input and get output
    private void provideInput(String data) {
        testIn = new ByteArrayInputStream(data.getBytes());
        System.setIn(testIn);
    }

    private String getOutput() {
        return testOut.toString();
    }
}
